﻿namespace Model
{
    public class Table
    {
        public int TableId { get; set; }
        public int Number { get; set; }
        public TableStatus Status { get; set; }
    }
}
