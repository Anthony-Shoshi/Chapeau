﻿namespace Model
{
    public enum TableStatus
    {
        Available,
        Occupied,
        Reserved,
    }
}
