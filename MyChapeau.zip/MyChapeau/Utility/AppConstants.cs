﻿namespace Utility
{
    public static class AppConstants
    {
        public const string Waiter = "waiter";
    }
}